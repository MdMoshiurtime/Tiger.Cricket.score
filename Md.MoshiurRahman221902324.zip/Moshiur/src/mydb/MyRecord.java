package mydb;

public class MyRecord {
}

