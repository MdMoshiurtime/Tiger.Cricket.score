package mydb;

public class MyDate {
    int day,month,year;
    MyDate(String record_string){

    }

}
