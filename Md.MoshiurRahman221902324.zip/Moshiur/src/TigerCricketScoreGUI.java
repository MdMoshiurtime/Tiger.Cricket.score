import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class TigerCricketScoreGUI implements ActionListener {
    private JTextField[] nameFields;
    private JTextField[] scoreFields;
    private JLabel resultLabel;
    private Connection connection;
    private JTextField datefield;

    public TigerCricketScoreGUI() {
        JFrame frame = new JFrame("Tiger Cricket Score");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        frame.setLayout(new BorderLayout());

        JPanel inputPanel = new JPanel(new GridLayout(0, 2));
        inputPanel.add(new JLabel("Date(DD/MM/YY):"));
        datefield=new JTextField() ;
        inputPanel.add((datefield));
        final int PLAYERS = 11;
        nameFields = new JTextField[PLAYERS];
        scoreFields = new JTextField[PLAYERS];
        for (int i = 0; i < PLAYERS; i++) {
            inputPanel.add(new JLabel("Enter player " + (i + 1) + " name:"));
            nameFields[i] = new JTextField();
            inputPanel.add(nameFields[i]);
            inputPanel.add(new JLabel("Enter player " + (i + 1) + " score:"));
            scoreFields[i] = new JTextField();
            inputPanel.add(scoreFields[i]);
        }
        frame.add(inputPanel, BorderLayout.CENTER);

        JButton calculateButton = new JButton("Calculate");
        calculateButton.addActionListener(this);
        frame.add(calculateButton, BorderLayout.SOUTH);

        resultLabel = new JLabel("", SwingConstants.CENTER);
        frame.add(resultLabel, BorderLayout.NORTH);

        frame.setVisible(true);


    }

    public void actionPerformed(ActionEvent e) {
        int highScoreIdx = 0;
        for (int i = 1; i < scoreFields.length; i++) {
            if (Integer.parseInt(scoreFields[i].getText()) > Integer.parseInt(scoreFields[highScoreIdx].getText())) {
                highScoreIdx = i;
            }
        }

        String playerName = nameFields[highScoreIdx].getText();
        int playerScore = Integer.parseInt(scoreFields[highScoreIdx].getText());

        resultLabel.setText(datefield.getText()+": "+playerName+": "+playerScore);
        File file = new File("my_db/scores");

        try{
            FileWriter writer = new FileWriter(file,true);
            writer.write(datefield.getText()+": "+playerName+": "+playerScore+"\n");
            writer.close();
        }
        catch (IOException ioe){
            System.out.println(e);
        }

    }
    public static void main(String[] args) {

        new TigerCricketScoreGUI();
    }
}
